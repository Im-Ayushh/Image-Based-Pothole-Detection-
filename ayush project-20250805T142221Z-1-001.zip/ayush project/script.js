// --- MODE TOGGLE ---
function toggleMode() {
    const body = document.body;
    body.classList.toggle("light-mode");
    body.classList.toggle("dark-mode");
    document.getElementById("mode-icon").textContent =
        body.classList.contains("light-mode") ? "☀️" : "🌙";
}
window.onload = () => {
    document.body.classList.add("dark-mode");
    document.getElementById("mode-icon").textContent = "🌙";
    authInit();
};

// -------- AUTH LOGIC ----------
const USERS_KEY = "pothole_users_v2";
const SESSION_KEY = "pothole_logged_in_user";

function authInit() {
    // Show dashboard if already logged in
    if (localStorage.getItem(SESSION_KEY)) {
        showDashboard();
    } else {
        showAuth();
    }
}

function showAuth() {
    document.getElementById("auth-section").style.display = "block";
    document.getElementById("main-dashboard").style.display = "none";
    document.getElementById("authForm").reset();
    document.getElementById("authError").innerText = "";
    isSignup = false;
    document.getElementById("signup-extra").style.display = "none";
    document.getElementById("auth-title").innerText = "Login";
    document.getElementById("toggle-auth").innerText = "Create an account";
}

function showDashboard() {
    document.getElementById("auth-section").style.display = "none";
    document.getElementById("main-dashboard").style.display = "block";
}

// Auth toggle (login/signup)
let isSignup = false;
document.getElementById("toggle-auth").onclick = () => {
    isSignup = !isSignup;
    document.getElementById("signup-extra").style.display = isSignup ? "block" : "none";
    document.getElementById("auth-title").innerText = isSignup ? "Sign Up" : "Login";
    document.getElementById("toggle-auth").innerText = isSignup ? "Already have an account?" : "Create an account";
    document.getElementById("authError").innerText = "";
};

// Auth form submit
document.getElementById("authForm").onsubmit = (e) => {
    e.preventDefault();
    let username = document.getElementById('username').value.trim();
    let password = document.getElementById('password').value.trim();
    let users = JSON.parse(localStorage.getItem(USERS_KEY) || "{}");
    let errorDiv = document.getElementById("authError");
    if (isSignup) {
        let name = document.getElementById('signup-name').value.trim();
        if (!name || !username || !password) {
            errorDiv.innerText = "Please fill all fields!";
            return;
        }
        if (users[username]) {
            errorDiv.innerText = "Username already exists!";
            return;
        }
        users[username] = { password, name };
        localStorage.setItem(USERS_KEY, JSON.stringify(users));
        localStorage.setItem(SESSION_KEY, username);
        showDashboard();
    } else {
        if (!username || !password) {
            errorDiv.innerText = "Please fill all fields!";
            return;
        }
        if (!users[username] || users[username].password !== password) {
            errorDiv.innerText = "Invalid username or password!";
            return;
        }
        localStorage.setItem(SESSION_KEY, username);
        showDashboard();
    }
};

// Logout
document.getElementById("logout-btn").onclick = () => {
    localStorage.removeItem(SESSION_KEY);
    showAuth();
};

// ---- IMAGE LOGIC (dots never in sky) ----
let imgObj = null;
const uploadInput = document.getElementById("img-upload");
const scanBtn = document.getElementById("scan-btn");

uploadInput.addEventListener("change", function () {
    if (!this.files.length) return;
    loadImageToCanvas(URL.createObjectURL(this.files[0]));
    scanBtn.disabled = false;
});

const canvas = document.getElementById("image-canvas");
const ctx = canvas.getContext("2d");
let potholeDots = [];
const imageSection = document.getElementById("image-section");
const loadingAnim = document.getElementById("loading-anim");
const reportSection = document.getElementById("report-section");
const potholeInfo = document.getElementById("pothole-info");

function loadImageToCanvas(src) {
    let img = new window.Image();
    img.crossOrigin = "Anonymous";
    img.onload = function () {
        canvas.width = Math.min(400, img.width);
        canvas.height = Math.min(290, img.height);
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        imgObj = img;
        imageSection.classList.remove("hidden");
        potholeDots = [];
        drawAll();
        reportSection.classList.add("hidden");
        potholeInfo.innerHTML = "";
    };
    img.src = src;
}

function resetImage() {
    imageSection.classList.add("hidden");
    uploadInput.value = "";
    scanBtn.disabled = true;
    potholeInfo.innerHTML = "";
    reportSection.classList.add("hidden");
}

function startScan() {
    if (!imgObj) return;
    loadingAnim.classList.remove("hidden");
    scanBtn.disabled = true;
    potholeDots = [];
    potholeInfo.innerHTML = "";
    reportSection.classList.add("hidden");
    ctx.globalAlpha = 0.95;
    ctx.drawImage(imgObj, 0, 0, canvas.width, canvas.height);
    ctx.globalAlpha = 1;
    setTimeout(() => {
        loadingAnim.classList.add("hidden");
        detectPotholes();
    }, 1850 + Math.random() * 500);
}

// --- Improved: dots always spaced, never above road, never in sky ---
function detectPotholes() {
    // Randomize count: 2, 3, or 4
    let count = 2 + Math.floor(Math.random() * 3);
    potholeDots = [];

    // Dots run up the center lane from near (bottom) to far (still on road, never in sky)
    let minY = canvas.height * 0.72;    // closest (bottom, near car)
    let maxY = canvas.height * 0.50;    // farthest (upper mid, still on road)
    let centerX = canvas.width * 0.5;

    let yStep = (minY - maxY) / (count - 1 || 1);

    for (let i = 0; i < count; i++) {
        // Spread out vertically, with random jitter
        let y = minY - i * yStep + (Math.random() - 0.5) * 10;  // ±5px
        let x = centerX + (Math.random() - 0.5) * 32;           // ±16px side-to-side
        potholeDots.push({
            x: x,
            y: y,
            size: "small"
        });
    }
    drawAll(true);
    setTimeout(showReport, 350 + potholeDots.length * 330);
}

function drawAll(animate = false) {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    if (imgObj) ctx.drawImage(imgObj, 0, 0, canvas.width, canvas.height);
    if (potholeDots.length) {
        if (animate) {
            let i = 0;
            let interval = setInterval(() => {
                if (i >= potholeDots.length) { clearInterval(interval); return; }
                drawDot(potholeDots[i].x, potholeDots[i].y, potholeDots[i].size, true);
                i++;
            }, 320);
        } else {
            potholeDots.forEach(dot => drawDot(dot.x, dot.y, dot.size));
        }
    }
}

function drawDot(x, y, size, glow = false) {
    ctx.save();
    ctx.beginPath();
    let r = 8; // Always small dot
    ctx.arc(x, y, r, 0, 2 * Math.PI);
    ctx.shadowColor = "#ff3636";
    ctx.shadowBlur = glow ? 25 : 16;
    ctx.globalAlpha = glow ? 0.76 : 1;
    ctx.fillStyle = "#ff3636";
    ctx.fill();
    ctx.strokeStyle = "#fff";
    ctx.lineWidth = 2.3;
    ctx.stroke();
    ctx.restore();
}

function showReport() {
    reportSection.classList.remove("hidden");
    let msg = `<b>Total Potholes:</b> <span style="color:#ff3636;font-weight:600;">${potholeDots.length}</span><br>`;
    msg += `<b>Severity:</b> Small: ${potholeDots.length}, Medium: 0, Large: 0<br>`;
    msg += `<b>Distances from current position:</b><br>`;
    let base = 10, step = 12;
    potholeDots.forEach((dot, i) => {
        let dist = base + step * i + Math.floor(Math.random() * 5);
        msg += `#${i+1}: <span style="color:#ffd600;">small</span> pothole at <b>${dist}m</b><br>`;
    });
    potholeInfo.innerHTML = msg;
}

function downloadImage() {
    const link = document.createElement('a');
    link.download = 'pothole_detection_result.png';
    link.href = canvas.toDataURL();
    link.click();
}

function openModal() {
    document.getElementById("about-modal").classList.remove("hidden");
}
function closeModal() {
    document.getElementById("about-modal").classList.add("hidden");
}
document.addEventListener("keydown", function(e) {
    if (e.key === "Escape") closeModal();
});








